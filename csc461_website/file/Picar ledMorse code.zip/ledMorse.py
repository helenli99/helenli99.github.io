# File Name: ledMorse.py
# Description: led Morse Code
# Author: by Zijian Chen
# Date: 2019-12-07

import RPi.GPIO as GPIO
import time

left_R = 15
left_G = 16
left_B = 18

right_R = 19
right_G = 21
right_B = 22

on = GPIO.LOW
off = GPIO.HIGH

def setup():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(left_R, GPIO.OUT)
    GPIO.setup(right_R, GPIO.OUT)
    GPIO.setup(left_G, GPIO.OUT)
    GPIO.setup(right_G, GPIO.OUT)
    GPIO.setup(left_B, GPIO.OUT)
    GPIO.setup(right_B, GPIO.OUT)
    both_off()

def both_off():
    GPIO.output(left_R, off)
    GPIO.output(right_R, off)
    GPIO.output(left_G, off)
    GPIO.output(right_G, off)
    GPIO.output(left_B, off)
    GPIO.output(right_B, off)

def red():
    GPIO.output(left_R, on)
    GPIO.output(right_R, on)

def green():
    GPIO.output(left_G, on)
    GPIO.output(right_G, on)

def blue():
    GPIO.output(left_B, on)
    GPIO.output(right_B, on)

def pink():
    red()
    blue()

def yellow():
    red()
    green()

def dot():
    pink()
    time.sleep(1)
    both_off()
    time.sleep(1)

def long():
    green()
    time.sleep(2)
    both_off()
    time.sleep(1)

def wait():
    time.sleep(1)

def A():
    dot()
    long()
    wait()

def B():
    long()
    dot()
    dot()
    dot()
    wait()

def C():
    long()
    dot()
    long()
    dot()
    wait()

def D():
    long()
    dot()
    dot()
    wait()

def E():
    dot()
    wait()

def F():
    dot()
    dot()
    long()
    dot()
    wait()

def G():
    long()
    long()
    dot()
    wait()

def H():
    dot()
    dot()
    dot()
    dot()
    wait()

def I():
    dot()
    dot()
    wait()

def J():
    dot()
    long()
    long()
    long()
    wait()

def K():
    long()
    dot()
    long()
    wait()

def L():
    dot()
    long()
    dot()
    dot()
    wait()

def M():
    long()
    long()
    wait()

def N():
    long()
    dot()
    wait()

def O():
    long()
    long()
    long()
    wait()

def P():
    dot()
    long()
    long()
    dot()
    wait()

def Q():
    long()
    long()
    dot()
    long()
    wait()

def R():
    dot()
    long()
    dot()
    wait()

def S():
    dot()
    dot()
    dot()
    wait()

def T():
    long()
    wait()

def U():
    dot()
    dot()
    long()
    wait()

def V():
    dot()
    dot()
    dot()
    long()
    wait()

def W():
    dot()
    long()
    long()
    wait()

def X():
    long()
    dot()
    dot()
    long()
    wait()

def Y():
    long()
    dot()
    long()
    long()
    wait()

def Z():
    long()
    long()
    dot()
    dot()
    wait()


def ILY():
   S()
   O()
   S()
   T()
   P()



if __name__ == '__main__':
    setup()

    ILY()


    GPIO.cleanup()
